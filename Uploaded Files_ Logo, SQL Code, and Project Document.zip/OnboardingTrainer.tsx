import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

const trainerSchema = z.object({
  firstName: z.string().min(1, "Le prénom est requis"),
  lastName: z.string().min(1, "Le nom est requis"),
  gender: z.enum(["Monsieur", "Madame"]).optional(),
  city: z.string().optional(),
  zipCode: z.string().optional(),
  mobilePhone: z.string().optional(),
  hasVehicle: z.boolean().optional(),
  socialStatus: z.enum(["Salarié", "Portage salarial", "Indépendant ou société"]).optional(),
  hasQualiopi: z.boolean().optional(),
  hasNda: z.boolean().optional(),
  websiteUrl: z.string().optional(),
  bio: z.string().optional(),
  dailyRateHt: z.string().optional(),
});

type TrainerFormData = z.infer<typeof trainerSchema>;

export default function OnboardingTrainer() {
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<TrainerFormData>({
    resolver: zodResolver(trainerSchema),
  });

  const createTrainerMutation = trpc.profile.createTrainerProfile.useMutation({
    onSuccess: () => {
      toast.success("Profil créé avec succès !");
      setLocation("/dashboard");
    },
    onError: (error) => {
      toast.error(error.message || "Erreur lors de la création du profil");
      setIsSubmitting(false);
    },
  });

  const onSubmit = (data: TrainerFormData) => {
    setIsSubmitting(true);
    createTrainerMutation.mutate({
      ...data,
      dailyRateHt: data.dailyRateHt ? parseInt(data.dailyRateHt) : undefined,
    });
  };

  const hasVehicle = watch("hasVehicle");
  const hasQualiopi = watch("hasQualiopi");
  const hasNda = watch("hasNda");

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container max-w-3xl">
        <div className="mb-8 text-center">
          <img src="/logo.png" alt="Annuaire Formateur" className="h-16 w-16 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-primary mb-2">Créez votre profil de formateur</h1>
          <p className="text-muted-foreground">
            Complétez vos informations pour commencer à recevoir des opportunités de missions
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Informations personnelles</CardTitle>
            <CardDescription>Ces informations seront visibles par les organismes de formation</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Identité */}
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="gender">Civilité</Label>
                  <Select onValueChange={(value) => setValue("gender", value as "Monsieur" | "Madame")}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sélectionnez" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Monsieur">Monsieur</SelectItem>
                      <SelectItem value="Madame">Madame</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="firstName">Prénom *</Label>
                  <Input id="firstName" {...register("firstName")} />
                  {errors.firstName && <p className="text-sm text-destructive mt-1">{errors.firstName.message}</p>}
                </div>

                <div>
                  <Label htmlFor="lastName">Nom *</Label>
                  <Input id="lastName" {...register("lastName")} />
                  {errors.lastName && <p className="text-sm text-destructive mt-1">{errors.lastName.message}</p>}
                </div>
              </div>

              {/* Localisation */}
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="city">Ville</Label>
                  <Input id="city" {...register("city")} />
                </div>

                <div>
                  <Label htmlFor="zipCode">Code postal</Label>
                  <Input id="zipCode" {...register("zipCode")} />
                </div>
              </div>

              {/* Contact */}
              <div>
                <Label htmlFor="mobilePhone">Téléphone mobile</Label>
                <Input id="mobilePhone" type="tel" {...register("mobilePhone")} />
              </div>

              {/* Statut professionnel */}
              <div>
                <Label htmlFor="socialStatus">Statut social</Label>
                <Select
                  onValueChange={(value) =>
                    setValue("socialStatus", value as "Salarié" | "Portage salarial" | "Indépendant ou société")
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Sélectionnez votre statut" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Salarié">Salarié</SelectItem>
                    <SelectItem value="Portage salarial">Portage salarial</SelectItem>
                    <SelectItem value="Indépendant ou société">Indépendant ou société</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Tarif */}
              <div>
                <Label htmlFor="dailyRateHt">Tarif journalier (€ HT)</Label>
                <Input id="dailyRateHt" type="number" {...register("dailyRateHt")} placeholder="500" />
              </div>

              {/* Certifications */}
              <div className="space-y-3">
                <Label>Certifications et qualifications</Label>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="hasQualiopi"
                    checked={hasQualiopi}
                    onCheckedChange={(checked) => setValue("hasQualiopi", checked as boolean)}
                  />
                  <label htmlFor="hasQualiopi" className="text-sm cursor-pointer">
                    Je possède la certification Qualiopi
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="hasNda"
                    checked={hasNda}
                    onCheckedChange={(checked) => setValue("hasNda", checked as boolean)}
                  />
                  <label htmlFor="hasNda" className="text-sm cursor-pointer">
                    Je possède un numéro de déclaration d'activité (NDA)
                  </label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="hasVehicle"
                    checked={hasVehicle}
                    onCheckedChange={(checked) => setValue("hasVehicle", checked as boolean)}
                  />
                  <label htmlFor="hasVehicle" className="text-sm cursor-pointer">
                    Je suis véhiculé(e)
                  </label>
                </div>
              </div>

              {/* Site web */}
              <div>
                <Label htmlFor="websiteUrl">Site web (optionnel)</Label>
                <Input id="websiteUrl" type="url" {...register("websiteUrl")} placeholder="https://..." />
              </div>

              {/* Bio */}
              <div>
                <Label htmlFor="bio">Présentation / Bio</Label>
                <Textarea
                  id="bio"
                  {...register("bio")}
                  rows={4}
                  placeholder="Présentez votre parcours, vos expertises et ce qui vous distingue..."
                />
              </div>

              <div className="flex justify-end gap-4">
                <Button type="button" variant="outline" onClick={() => setLocation("/")}>
                  Annuler
                </Button>
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-accent text-accent-foreground hover:bg-accent/90"
                >
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Créer mon profil
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
