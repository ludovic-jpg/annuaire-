import { eq, and, or, like, desc, asc, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  trainers,
  organizations,
  trainerSkills,
  trainerCatalogs,
  trainerMobility,
  missions,
  trainerCredits,
  payments,
  messages,
  profileReveals,
  notifications,
  favorites,
  reviews,
  type Trainer,
  type InsertTrainer,
  type Organization,
  type InsertOrganization,
  type TrainerSkill,
  type InsertTrainerSkill,
  type TrainerCatalog,
  type InsertTrainerCatalog,
  type TrainerMobility,
  type InsertTrainerMobility,
  type Mission,
  type InsertMission,
  type Message,
  type InsertMessage,
  type Payment,
  type InsertPayment,
  type Notification,
  type InsertNotification,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============================================================================
// USERS
// ============================================================================
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserRole(userId: number, role: "trainer" | "organization" | "admin") {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(users).set({ role }).where(eq(users.id, userId));
}

// ============================================================================
// TRAINERS
// ============================================================================
export async function createTrainer(trainer: InsertTrainer) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(trainers).values(trainer);
  return result;
}

export async function getTrainerByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(trainers).where(eq(trainers.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getTrainerById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(trainers).where(eq(trainers.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateTrainer(id: number, data: Partial<InsertTrainer>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(trainers).set(data).where(eq(trainers.id, id));
}

export async function searchTrainers(filters: {
  sphere?: string;
  skillLevel?: string;
  city?: string;
  zipCode?: string;
  minRate?: number;
  maxRate?: number;
}) {
  const db = await getDb();
  if (!db) return [];

  let query = db.select().from(trainers);
  const conditions = [];

  if (filters.city) {
    conditions.push(like(trainers.city, `%${filters.city}%`));
  }
  if (filters.zipCode) {
    conditions.push(like(trainers.zipCode, `${filters.zipCode}%`));
  }
  if (filters.minRate !== undefined) {
    conditions.push(sql`${trainers.dailyRateHt} >= ${filters.minRate}`);
  }
  if (filters.maxRate !== undefined) {
    conditions.push(sql`${trainers.dailyRateHt} <= ${filters.maxRate}`);
  }

  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }

  return await query;
}

// ============================================================================
// ORGANIZATIONS
// ============================================================================
export async function createOrganization(organization: InsertOrganization) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(organizations).values(organization);
  return result;
}

export async function getOrganizationByUserId(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(organizations).where(eq(organizations.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getOrganizationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(organizations).where(eq(organizations.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateOrganization(id: number, data: Partial<InsertOrganization>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(organizations).set(data).where(eq(organizations.id, id));
}

// ============================================================================
// TRAINER SKILLS
// ============================================================================
export async function addTrainerSkill(skill: InsertTrainerSkill) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(trainerSkills).values(skill);
}

export async function getTrainerSkills(trainerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(trainerSkills).where(eq(trainerSkills.trainerId, trainerId));
}

export async function deleteTrainerSkill(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(trainerSkills).where(eq(trainerSkills.id, id));
}

// ============================================================================
// TRAINER CATALOGS
// ============================================================================
export async function addTrainerCatalog(catalog: InsertTrainerCatalog) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(trainerCatalogs).values(catalog);
}

export async function getTrainerCatalogs(trainerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(trainerCatalogs).where(eq(trainerCatalogs.trainerId, trainerId));
}

export async function updateTrainerCatalog(id: number, data: Partial<InsertTrainerCatalog>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(trainerCatalogs).set(data).where(eq(trainerCatalogs.id, id));
}

export async function deleteTrainerCatalog(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(trainerCatalogs).where(eq(trainerCatalogs.id, id));
}

// ============================================================================
// TRAINER MOBILITY
// ============================================================================
export async function addTrainerMobility(mobility: InsertTrainerMobility) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(trainerMobility).values(mobility);
}

export async function getTrainerMobility(trainerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(trainerMobility).where(eq(trainerMobility.trainerId, trainerId));
}

export async function deleteTrainerMobility(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(trainerMobility).where(eq(trainerMobility.id, id));
}

// ============================================================================
// MISSIONS
// ============================================================================
export async function createMission(mission: InsertMission) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(missions).values(mission);
  return result;
}

export async function getMissionById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(missions).where(eq(missions.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getActiveMissions() {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(missions)
    .where(eq(missions.isActive, true))
    .orderBy(desc(missions.publishedAt));
}

export async function getMissionsByOrganization(organizationId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(missions)
    .where(eq(missions.organizationId, organizationId))
    .orderBy(desc(missions.publishedAt));
}

export async function updateMission(id: number, data: Partial<InsertMission>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(missions).set(data).where(eq(missions.id, id));
}

// ============================================================================
// MESSAGES
// ============================================================================
export async function createMessage(message: InsertMessage) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(messages).values(message);
  return result;
}

export async function getMessageById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(messages).where(eq(messages.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getMessagesByTrainer(trainerId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(messages)
    .where(eq(messages.recipientTrainerId, trainerId))
    .orderBy(desc(messages.sentAt));
}

export async function revealMessage(messageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(messages).set({ isRevealed: true, revealedAt: new Date() }).where(eq(messages.id, messageId));
}

export async function markMessageAsRead(messageId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(messages).set({ isRead: true, readAt: new Date() }).where(eq(messages.id, messageId));
}

// ============================================================================
// PAYMENTS
// ============================================================================
export async function createPayment(payment: InsertPayment) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const result = await db.insert(payments).values(payment);
  return result;
}

export async function getPaymentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(payments).where(eq(payments.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updatePaymentStatus(
  id: number,
  status: "PENDING" | "COMPLETED" | "FAILED" | "REFUNDED",
  stripeChargeId?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(payments).set({ status, stripeChargeId }).where(eq(payments.id, id));
}

export async function getPaymentsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(payments)
    .where(eq(payments.payerUserId, userId))
    .orderBy(desc(payments.transactionDate));
}

// ============================================================================
// NOTIFICATIONS
// ============================================================================
export async function createNotification(notification: InsertNotification) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(notifications).values(notification);
}

export async function getNotificationsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function markNotificationAsRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(notifications).set({ isRead: true, readAt: new Date() }).where(eq(notifications.id, id));
}

export async function getUnreadNotificationsCount(userId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), eq(notifications.isRead, false)));
  return result[0]?.count || 0;
}

// ============================================================================
// TRAINER CREDITS
// ============================================================================
export async function initializeTrainerCredits(trainerId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(trainerCredits).values({
    trainerId,
    balance: 0,
    totalPurchased: 0,
    totalUsed: 0,
  });
}

export async function getTrainerCredits(trainerId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(trainerCredits).where(eq(trainerCredits.trainerId, trainerId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateTrainerCredits(trainerId: number, balance: number, totalUsed: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(trainerCredits).set({ balance, totalUsed }).where(eq(trainerCredits.trainerId, trainerId));
}
