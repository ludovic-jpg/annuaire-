import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTrainerContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-trainer-001",
    email: "trainer@example.com",
    name: "Test Trainer",
    loginMethod: "manus",
    role: "trainer",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("profile.createTrainerProfile", () => {
  it("should create a trainer profile successfully", async () => {
    const { ctx } = createTrainerContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.profile.createTrainerProfile({
      firstName: "Jean",
      lastName: "Dupont",
      gender: "Monsieur",
      city: "Paris",
      zipCode: "75001",
      mobilePhone: "0612345678",
      hasVehicle: true,
      socialStatus: "Indépendant ou société",
      hasQualiopi: true,
      hasNda: true,
      dailyRateHt: 500,
      bio: "Formateur expert en management avec 10 ans d'expérience",
    });

    expect(result).toEqual({ success: true });
  });

  it("should reject profile creation if user is not authenticated", async () => {
    const ctx: TrpcContext = {
      user: null,
      req: {
        protocol: "https",
        headers: {},
      } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    };

    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.profile.createTrainerProfile({
        firstName: "Jean",
        lastName: "Dupont",
      })
    ).rejects.toThrow();
  });
});

describe("profile.getMyProfile", () => {
  it("should return null if no profile exists", async () => {
    const { ctx } = createTrainerContext();
    const caller = appRouter.createCaller(ctx);

    const profile = await caller.profile.getMyProfile();
    
    // Note: This test assumes the database is empty
    // In a real scenario, we would use a test database or mock
    expect(profile).toBeDefined();
  });
});
