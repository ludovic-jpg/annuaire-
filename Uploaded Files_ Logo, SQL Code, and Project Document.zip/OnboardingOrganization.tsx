import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

const organizationSchema = z.object({
  corporateName: z.string().min(1, "La raison sociale est requise"),
  siret: z.string().length(14, "Le SIRET doit contenir 14 chiffres"),
  websiteUrl: z.string().optional(),
  professionalAddress: z.string().optional(),
  city: z.string().optional(),
  zipCode: z.string().optional(),
  mobilePhone: z.string().optional(),
  landlinePhone: z.string().optional(),
  description: z.string().optional(),
  contactPersonFirstName: z.string().optional(),
  contactPersonLastName: z.string().optional(),
  contactPersonCivility: z.enum(["Monsieur", "Madame"]).optional(),
  contactPersonEmail: z.string().email("Email invalide").optional().or(z.literal("")),
});

type OrganizationFormData = z.infer<typeof organizationSchema>;

export default function OnboardingOrganization() {
  const [, setLocation] = useLocation();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<OrganizationFormData>({
    resolver: zodResolver(organizationSchema),
  });

  const createOrganizationMutation = trpc.profile.createOrganizationProfile.useMutation({
    onSuccess: () => {
      toast.success("Profil créé avec succès !");
      setLocation("/dashboard");
    },
    onError: (error) => {
      toast.error(error.message || "Erreur lors de la création du profil");
      setIsSubmitting(false);
    },
  });

  const onSubmit = (data: OrganizationFormData) => {
    setIsSubmitting(true);
    createOrganizationMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-background py-12">
      <div className="container max-w-3xl">
        <div className="mb-8 text-center">
          <img src="/logo.png" alt="Annuaire Formateur" className="h-16 w-16 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-primary mb-2">Créez votre compte organisme</h1>
          <p className="text-muted-foreground">
            Complétez vos informations pour accéder gratuitement à notre réseau de formateurs
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Informations de l'organisme</CardTitle>
            <CardDescription>Ces informations seront visibles par les formateurs après déblocage</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Informations société */}
              <div>
                <Label htmlFor="corporateName">Raison sociale *</Label>
                <Input id="corporateName" {...register("corporateName")} />
                {errors.corporateName && (
                  <p className="text-sm text-destructive mt-1">{errors.corporateName.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="siret">SIRET *</Label>
                <Input id="siret" {...register("siret")} maxLength={14} placeholder="12345678901234" />
                {errors.siret && <p className="text-sm text-destructive mt-1">{errors.siret.message}</p>}
              </div>

              <div>
                <Label htmlFor="websiteUrl">Site web</Label>
                <Input id="websiteUrl" type="url" {...register("websiteUrl")} placeholder="https://..." />
              </div>

              {/* Adresse */}
              <div>
                <Label htmlFor="professionalAddress">Adresse professionnelle</Label>
                <Input id="professionalAddress" {...register("professionalAddress")} />
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="city">Ville</Label>
                  <Input id="city" {...register("city")} />
                </div>

                <div>
                  <Label htmlFor="zipCode">Code postal</Label>
                  <Input id="zipCode" {...register("zipCode")} />
                </div>
              </div>

              {/* Contact */}
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="mobilePhone">Téléphone mobile</Label>
                  <Input id="mobilePhone" type="tel" {...register("mobilePhone")} />
                </div>

                <div>
                  <Label htmlFor="landlinePhone">Téléphone fixe</Label>
                  <Input id="landlinePhone" type="tel" {...register("landlinePhone")} />
                </div>
              </div>

              {/* Description */}
              <div>
                <Label htmlFor="description">Description de l'organisme</Label>
                <Textarea
                  id="description"
                  {...register("description")}
                  rows={4}
                  placeholder="Présentez votre organisme, vos domaines d'intervention..."
                />
              </div>

              {/* Contact représentant */}
              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-4">Personne de contact</h3>

                <div className="grid gap-4 md:grid-cols-2 mb-4">
                  <div>
                    <Label htmlFor="contactPersonCivility">Civilité</Label>
                    <Select
                      onValueChange={(value) => setValue("contactPersonCivility", value as "Monsieur" | "Madame")}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Sélectionnez" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Monsieur">Monsieur</SelectItem>
                        <SelectItem value="Madame">Madame</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2 mb-4">
                  <div>
                    <Label htmlFor="contactPersonFirstName">Prénom</Label>
                    <Input id="contactPersonFirstName" {...register("contactPersonFirstName")} />
                  </div>

                  <div>
                    <Label htmlFor="contactPersonLastName">Nom</Label>
                    <Input id="contactPersonLastName" {...register("contactPersonLastName")} />
                  </div>
                </div>

                <div>
                  <Label htmlFor="contactPersonEmail">Email</Label>
                  <Input id="contactPersonEmail" type="email" {...register("contactPersonEmail")} />
                  {errors.contactPersonEmail && (
                    <p className="text-sm text-destructive mt-1">{errors.contactPersonEmail.message}</p>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-4">
                <Button type="button" variant="outline" onClick={() => setLocation("/")}>
                  Annuler
                </Button>
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Créer mon compte
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
