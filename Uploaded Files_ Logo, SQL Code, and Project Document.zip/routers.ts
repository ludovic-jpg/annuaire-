import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import * as db from "./db";
import { storagePut } from "./storage";

// ============================================================================
// AUTH ROUTER
// ============================================================================
export const authRouter = router({
  me: publicProcedure.query((opts) => opts.ctx.user),
  logout: publicProcedure.mutation(({ ctx }) => {
    const cookieOptions = getSessionCookieOptions(ctx.req);
    ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
    return { success: true } as const;
  }),
});

// ============================================================================
// PROFILE ROUTER
// ============================================================================
export const profileRouter = router({
  // Get current user's profile (trainer or organization)
  getMyProfile: protectedProcedure.query(async ({ ctx }) => {
    const user = ctx.user;
    if (user.role === "trainer") {
      const trainer = await db.getTrainerByUserId(user.id);
      if (trainer) {
        const skills = await db.getTrainerSkills(trainer.id);
        const catalogs = await db.getTrainerCatalogs(trainer.id);
        const mobility = await db.getTrainerMobility(trainer.id);
        return { type: "trainer" as const, trainer, skills, catalogs, mobility };
      }
    } else if (user.role === "organization") {
      const organization = await db.getOrganizationByUserId(user.id);
      if (organization) {
        return { type: "organization" as const, organization };
      }
    }
    return null;
  }),

  // Create trainer profile
  createTrainerProfile: protectedProcedure
    .input(
      z.object({
        firstName: z.string().min(1),
        lastName: z.string().min(1),
        gender: z.enum(["Monsieur", "Madame"]).optional(),
        birthDate: z.string().optional(),
        personalAddress: z.string().optional(),
        city: z.string().optional(),
        zipCode: z.string().optional(),
        mobilePhone: z.string().optional(),
        hasVehicle: z.boolean().optional(),
        socialStatus: z.enum(["Salarié", "Portage salarial", "Indépendant ou société"]).optional(),
        hasQualiopi: z.boolean().optional(),
        hasNda: z.boolean().optional(),
        websiteUrl: z.string().optional(),
        bio: z.string().optional(),
        dailyRateHt: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const existing = await db.getTrainerByUserId(ctx.user.id);
      if (existing) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Trainer profile already exists" });
      }

      await db.updateUserRole(ctx.user.id, "trainer");
      await db.createTrainer({
        userId: ctx.user.id,
        ...input,
        birthDate: input.birthDate ? new Date(input.birthDate) : undefined,
      });

      const trainer = await db.getTrainerByUserId(ctx.user.id);
      if (trainer) {
        await db.initializeTrainerCredits(trainer.id);
      }

      return { success: true };
    }),

  // Update trainer profile
  updateTrainerProfile: protectedProcedure
    .input(
      z.object({
        firstName: z.string().optional(),
        lastName: z.string().optional(),
        gender: z.enum(["Monsieur", "Madame"]).optional(),
        birthDate: z.string().optional(),
        personalAddress: z.string().optional(),
        city: z.string().optional(),
        zipCode: z.string().optional(),
        mobilePhone: z.string().optional(),
        hasVehicle: z.boolean().optional(),
        socialStatus: z.enum(["Salarié", "Portage salarial", "Indépendant ou société"]).optional(),
        hasQualiopi: z.boolean().optional(),
        hasNda: z.boolean().optional(),
        websiteUrl: z.string().optional(),
        bio: z.string().optional(),
        dailyRateHt: z.number().optional(),
        profilePhotoUrl: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const trainer = await db.getTrainerByUserId(ctx.user.id);
      if (!trainer) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Trainer profile not found" });
      }

      await db.updateTrainer(trainer.id, {
        ...input,
        birthDate: input.birthDate ? new Date(input.birthDate) : undefined,
      });

      return { success: true };
    }),

  // Create organization profile
  createOrganizationProfile: protectedProcedure
    .input(
      z.object({
        corporateName: z.string().min(1),
        siret: z.string().length(14),
        websiteUrl: z.string().optional(),
        professionalAddress: z.string().optional(),
        city: z.string().optional(),
        zipCode: z.string().optional(),
        mobilePhone: z.string().optional(),
        landlinePhone: z.string().optional(),
        description: z.string().optional(),
        contactPersonFirstName: z.string().optional(),
        contactPersonLastName: z.string().optional(),
        contactPersonCivility: z.enum(["Monsieur", "Madame"]).optional(),
        contactPersonEmail: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const existing = await db.getOrganizationByUserId(ctx.user.id);
      if (existing) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Organization profile already exists" });
      }

      await db.updateUserRole(ctx.user.id, "organization");
      await db.createOrganization({
        userId: ctx.user.id,
        ...input,
      });

      return { success: true };
    }),

  // Update organization profile
  updateOrganizationProfile: protectedProcedure
    .input(
      z.object({
        corporateName: z.string().optional(),
        siret: z.string().optional(),
        websiteUrl: z.string().optional(),
        professionalAddress: z.string().optional(),
        city: z.string().optional(),
        zipCode: z.string().optional(),
        mobilePhone: z.string().optional(),
        landlinePhone: z.string().optional(),
        description: z.string().optional(),
        contactPersonFirstName: z.string().optional(),
        contactPersonLastName: z.string().optional(),
        contactPersonCivility: z.enum(["Monsieur", "Madame"]).optional(),
        contactPersonEmail: z.string().optional(),
        logoUrl: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const organization = await db.getOrganizationByUserId(ctx.user.id);
      if (!organization) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Organization profile not found" });
      }

      await db.updateOrganization(organization.id, input);
      return { success: true };
    }),

  // Upload profile photo
  uploadPhoto: protectedProcedure
    .input(
      z.object({
        fileData: z.string(), // base64
        fileName: z.string(),
        mimeType: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const buffer = Buffer.from(input.fileData, "base64");
      const key = `profiles/${ctx.user.id}/${Date.now()}-${input.fileName}`;
      const { url } = await storagePut(key, buffer, input.mimeType);
      return { url };
    }),
});

// ============================================================================
// SKILLS ROUTER
// ============================================================================
export const skillsRouter = router({
  // Add skill to trainer
  addSkill: protectedProcedure
    .input(
      z.object({
        sphere: z.enum([
          "RH",
          "Management",
          "Bureautique",
          "Digital",
          "Communication",
          "Langues",
          "Bien-être",
          "Métiers spécifiques",
        ]),
        skillLevel: z.enum(["Débutant", "Intermédiaire", "Confirmé"]),
        yearsOfExperience: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const trainer = await db.getTrainerByUserId(ctx.user.id);
      if (!trainer) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Trainer profile not found" });
      }

      await db.addTrainerSkill({
        trainerId: trainer.id,
        ...input,
      });

      return { success: true };
    }),

  // Get trainer skills
  getMySkills: protectedProcedure.query(async ({ ctx }) => {
    const trainer = await db.getTrainerByUserId(ctx.user.id);
    if (!trainer) return [];
    return await db.getTrainerSkills(trainer.id);
  }),

  // Delete skill
  deleteSkill: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    await db.deleteTrainerSkill(input.id);
    return { success: true };
  }),
});

// ============================================================================
// CATALOG ROUTER
// ============================================================================
export const catalogRouter = router({
  // Add training to catalog
  addTraining: protectedProcedure
    .input(
      z.object({
        trainingTitle: z.string().min(1),
        trainingContent: z.string().min(1),
        durationHours: z.number().optional(),
        targetAudience: z.string().optional(),
        learningObjectives: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const trainer = await db.getTrainerByUserId(ctx.user.id);
      if (!trainer) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Trainer profile not found" });
      }

      await db.addTrainerCatalog({
        trainerId: trainer.id,
        ...input,
      });

      return { success: true };
    }),

  // Get my catalog
  getMyCatalog: protectedProcedure.query(async ({ ctx }) => {
    const trainer = await db.getTrainerByUserId(ctx.user.id);
    if (!trainer) return [];
    return await db.getTrainerCatalogs(trainer.id);
  }),

  // Update training
  updateTraining: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        trainingTitle: z.string().optional(),
        trainingContent: z.string().optional(),
        durationHours: z.number().optional(),
        targetAudience: z.string().optional(),
        learningObjectives: z.string().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const { id, ...data } = input;
      await db.updateTrainerCatalog(id, data);
      return { success: true };
    }),

  // Delete training
  deleteTraining: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    await db.deleteTrainerCatalog(input.id);
    return { success: true };
  }),
});

// ============================================================================
// MOBILITY ROUTER
// ============================================================================
export const mobilityRouter = router({
  // Add mobility area
  addArea: protectedProcedure
    .input(
      z.object({
        areaCode: z.string(),
        areaName: z.string().optional(),
        areaType: z.enum(["DEPARTMENT", "REGION", "COUNTRY", "REMOTE"]).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const trainer = await db.getTrainerByUserId(ctx.user.id);
      if (!trainer) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Trainer profile not found" });
      }

      await db.addTrainerMobility({
        trainerId: trainer.id,
        ...input,
      });

      return { success: true };
    }),

  // Get my mobility
  getMyMobility: protectedProcedure.query(async ({ ctx }) => {
    const trainer = await db.getTrainerByUserId(ctx.user.id);
    if (!trainer) return [];
    return await db.getTrainerMobility(trainer.id);
  }),

  // Delete area
  deleteArea: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    await db.deleteTrainerMobility(input.id);
    return { success: true };
  }),
});

// ============================================================================
// SEARCH ROUTER
// ============================================================================
export const searchRouter = router({
  // Search trainers (for organizations)
  searchTrainers: protectedProcedure
    .input(
      z.object({
        sphere: z.string().optional(),
        skillLevel: z.string().optional(),
        city: z.string().optional(),
        zipCode: z.string().optional(),
        minRate: z.number().optional(),
        maxRate: z.number().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      if (ctx.user.role !== "organization" && ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only organizations can search trainers" });
      }

      const trainers = await db.searchTrainers(input);

      // Get skills for each trainer if sphere filter is provided
      if (input.sphere) {
        const trainersWithSkills = await Promise.all(
          trainers.map(async (trainer) => {
            const skills = await db.getTrainerSkills(trainer.id);
            const hasMatchingSkill = skills.some(
              (skill) =>
                skill.sphere === input.sphere &&
                (!input.skillLevel || skill.skillLevel === input.skillLevel)
            );
            return hasMatchingSkill ? trainer : null;
          })
        );
        return trainersWithSkills.filter((t) => t !== null);
      }

      return trainers;
    }),

  // Get trainer public profile (masked contact info)
  getTrainerPublicProfile: protectedProcedure.input(z.object({ trainerId: z.number() })).query(async ({ input }) => {
    const trainer = await db.getTrainerById(input.trainerId);
    if (!trainer) {
      throw new TRPCError({ code: "NOT_FOUND", message: "Trainer not found" });
    }

    const skills = await db.getTrainerSkills(input.trainerId);
    const catalogs = await db.getTrainerCatalogs(input.trainerId);
    const mobility = await db.getTrainerMobility(input.trainerId);

    // Mask contact information
    return {
      ...trainer,
      mobilePhone: undefined,
      personalAddress: undefined,
      skills,
      catalogs,
      mobility,
    };
  }),
});

// ============================================================================
// MISSIONS ROUTER
// ============================================================================
export const missionsRouter = router({
  // Create mission (organization only)
  createMission: protectedProcedure
    .input(
      z.object({
        title: z.string().min(1),
        description: z.string().min(1),
        location: z.string().optional(),
        requiredSkills: z.string().optional(),
        requiredSphere: z
          .enum([
            "RH",
            "Management",
            "Bureautique",
            "Digital",
            "Communication",
            "Langues",
            "Bien-être",
            "Métiers spécifiques",
          ])
          .optional(),
        requiredSkillLevel: z.enum(["Débutant", "Intermédiaire", "Confirmé"]).optional(),
        budgetMinHt: z.number().optional(),
        budgetMaxHt: z.number().optional(),
        startDate: z.string().optional(),
        endDate: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "organization") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only organizations can create missions" });
      }

      const organization = await db.getOrganizationByUserId(ctx.user.id);
      if (!organization) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Organization profile not found" });
      }

      await db.createMission({
        organizationId: organization.id,
        ...input,
        startDate: input.startDate ? new Date(input.startDate) : undefined,
        endDate: input.endDate ? new Date(input.endDate) : undefined,
      });

      return { success: true };
    }),

  // Get all active missions (public for trainers)
  getActiveMissions: protectedProcedure.query(async ({ ctx }) => {
    const missions = await db.getActiveMissions();

    // Anonymize organization details for trainers
    const missionsWithOrgs = await Promise.all(
      missions.map(async (mission) => {
        const org = await db.getOrganizationById(mission.organizationId);
        return {
          ...mission,
          organization: {
            id: org?.id,
            corporateName: ctx.user.role === "trainer" ? "Organisme confidentiel" : org?.corporateName,
            city: org?.city,
          },
        };
      })
    );

    return missionsWithOrgs;
  }),

  // Get my missions (organization only)
  getMyMissions: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "organization") {
      throw new TRPCError({ code: "FORBIDDEN", message: "Only organizations can view their missions" });
    }

    const organization = await db.getOrganizationByUserId(ctx.user.id);
    if (!organization) return [];

    return await db.getMissionsByOrganization(organization.id);
  }),

  // Update mission
  updateMission: protectedProcedure
    .input(
      z.object({
        id: z.number(),
        title: z.string().optional(),
        description: z.string().optional(),
        location: z.string().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "organization") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }

      const { id, ...data } = input;
      await db.updateMission(id, data);
      return { success: true };
    }),
});

// ============================================================================
// MESSAGES ROUTER
// ============================================================================
export const messagesRouter = router({
  // Send message to trainer (from organization)
  sendMessage: protectedProcedure
    .input(
      z.object({
        recipientTrainerId: z.number(),
        subject: z.string().min(1),
        fullContent: z.string().min(1),
        missionId: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "organization") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only organizations can send messages" });
      }

      const organization = await db.getOrganizationByUserId(ctx.user.id);
      if (!organization) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Organization profile not found" });
      }

      await db.createMessage({
        senderUserId: ctx.user.id,
        senderName: organization.corporateName,
        senderEmail: organization.contactPersonEmail || ctx.user.email || undefined,
        ...input,
      });

      // Create notification for trainer
      const trainer = await db.getTrainerById(input.recipientTrainerId);
      if (trainer) {
        await db.createNotification({
          userId: trainer.userId,
          notificationType: "NEW_MESSAGE",
          title: "Nouvelle opportunité !",
          content: `${organization.corporateName} s'intéresse à votre profil.`,
          relatedItemId: input.recipientTrainerId,
        });
      }

      return { success: true };
    }),

  // Get my messages (trainer only)
  getMyMessages: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "trainer") {
      throw new TRPCError({ code: "FORBIDDEN", message: "Only trainers can view messages" });
    }

    const trainer = await db.getTrainerByUserId(ctx.user.id);
    if (!trainer) return [];

    const messages = await db.getMessagesByTrainer(trainer.id);

    // Mask content if not revealed
    return messages.map((msg) => ({
      ...msg,
      fullContent: msg.isRevealed ? msg.fullContent : "[Contenu masqué - Débloquez pour 9€]",
      senderEmail: msg.isRevealed ? msg.senderEmail : "[Masqué]",
      senderName: msg.isRevealed ? msg.senderName : msg.senderName?.substring(0, 3) + "***",
    }));
  }),

  // Get message by ID
  getMessage: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
    const message = await db.getMessageById(input.id);
    if (!message) {
      throw new TRPCError({ code: "NOT_FOUND", message: "Message not found" });
    }

    // Check if user is the recipient
    const trainer = await db.getTrainerByUserId(ctx.user.id);
    if (!trainer || trainer.id !== message.recipientTrainerId) {
      throw new TRPCError({ code: "FORBIDDEN" });
    }

    return {
      ...message,
      fullContent: message.isRevealed ? message.fullContent : "[Contenu masqué - Débloquez pour 9€]",
      senderEmail: message.isRevealed ? message.senderEmail : "[Masqué]",
    };
  }),

  // Mark message as read
  markAsRead: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    await db.markMessageAsRead(input.id);
    return { success: true };
  }),
});

// ============================================================================
// NOTIFICATIONS ROUTER
// ============================================================================
export const notificationsRouter = router({
  // Get my notifications
  getMyNotifications: protectedProcedure.query(async ({ ctx }) => {
    return await db.getNotificationsByUser(ctx.user.id);
  }),

  // Get unread count
  getUnreadCount: protectedProcedure.query(async ({ ctx }) => {
    return await db.getUnreadNotificationsCount(ctx.user.id);
  }),

  // Mark as read
  markAsRead: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
    await db.markNotificationAsRead(input.id);
    return { success: true };
  }),
});

// ============================================================================
// PAYMENTS ROUTER
// ============================================================================
export const paymentsRouter = router({
  // Create payment intent for message reveal
  createPaymentIntent: protectedProcedure
    .input(
      z.object({
        messageId: z.number(),
        itemType: z.enum(["MESSAGE_REVEAL", "MISSION_REVEAL", "PROFILE_REVEAL"]),
      })
    )
    .mutation(async ({ ctx, input }) => {
      if (ctx.user.role !== "trainer") {
        throw new TRPCError({ code: "FORBIDDEN", message: "Only trainers can purchase reveals" });
      }

      const trainer = await db.getTrainerByUserId(ctx.user.id);
      if (!trainer) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Trainer profile not found" });
      }

      // Get message to find recipient
      const message = await db.getMessageById(input.messageId);
      if (!message) {
        throw new TRPCError({ code: "NOT_FOUND", message: "Message not found" });
      }

      // Check if already revealed
      if (message.isRevealed) {
        throw new TRPCError({ code: "BAD_REQUEST", message: "Message already revealed" });
      }

      // Create payment record
      await db.createPayment({
        payerUserId: ctx.user.id,
        recipientUserId: message.senderUserId || undefined,
        itemType: input.itemType,
        itemId: input.messageId,
        amount: 900, // 9€ en centimes
        status: "PENDING",
      });

      // Return Stripe payment link
      // Note: Using the test link provided by user
      const stripePaymentUrl = `https://buy.stripe.com/test_00w4gzbqO5zu2TH4GRgUM00?client_reference_id=${ctx.user.id}_${input.messageId}_${input.itemType}`;

      return {
        paymentUrl: stripePaymentUrl,
        amount: 900,
      };
    }),

  // Confirm payment (webhook handler would call this)
  confirmPayment: protectedProcedure
    .input(
      z.object({
        messageId: z.number(),
        stripeChargeId: z.string(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const message = await db.getMessageById(input.messageId);
      if (!message) {
        throw new TRPCError({ code: "NOT_FOUND" });
      }

      // Reveal the message
      await db.revealMessage(input.messageId);

      // Update payment status
      const payments = await db.getPaymentsByUser(ctx.user.id);
      const payment = payments.find((p) => p.itemId === input.messageId && p.status === "PENDING");
      if (payment) {
        await db.updatePaymentStatus(payment.id, "COMPLETED", input.stripeChargeId);
      }

      // Create notification
      await db.createNotification({
        userId: ctx.user.id,
        notificationType: "MESSAGE_REVEALED",
        title: "Contact débloqué !",
        content: "Vous pouvez maintenant voir les coordonnées complètes.",
        relatedItemId: input.messageId,
      });

      return { success: true };
    }),

  // Get my payments history
  getMyPayments: protectedProcedure.query(async ({ ctx }) => {
    return await db.getPaymentsByUser(ctx.user.id);
  }),

  // Get my credits (for trainers)
  getMyCredits: protectedProcedure.query(async ({ ctx }) => {
    if (ctx.user.role !== "trainer") {
      return null;
    }

    const trainer = await db.getTrainerByUserId(ctx.user.id);
    if (!trainer) return null;

    return await db.getTrainerCredits(trainer.id);
  }),
});

// ============================================================================
// MAIN APP ROUTER
// ============================================================================
export const appRouter = router({
  system: systemRouter,
  auth: authRouter,
  profile: profileRouter,
  skills: skillsRouter,
  catalog: catalogRouter,
  mobility: mobilityRouter,
  search: searchRouter,
  missions: missionsRouter,
  messages: messagesRouter,
  notifications: notificationsRouter,
  payments: paymentsRouter,
});

export type AppRouter = typeof appRouter;
