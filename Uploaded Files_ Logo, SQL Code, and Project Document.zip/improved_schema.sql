-- ============================================================================
-- SCHEMA MULTIDIRECTORY - "TROUVER UN FORMATEUR"
-- Modèle économique : Pay-to-Reveal (Formateur paie pour débloquer les contacts)
-- ============================================================================

-- Extensions nécessaires
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================================
-- 1. TABLE DES UTILISATEURS PRINCIPAUX (Discriminateur de rôle)
-- ============================================================================
CREATE TABLE users (
    user_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('TRAINER', 'ORGANIZATION', 'ADMIN')),
    is_active BOOLEAN DEFAULT TRUE,
    is_deleted BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP WITH TIME ZONE,
    last_login_ip VARCHAR(45),
    email_verified BOOLEAN DEFAULT FALSE,
    email_verified_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_is_active ON users(is_active);

-- ============================================================================
-- 2. TABLE FORMATEURS (Profil spécifique lié à users)
-- ============================================================================
CREATE TABLE trainers (
    trainer_id UUID PRIMARY KEY REFERENCES users(user_id) ON DELETE CASCADE,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    gender VARCHAR(10) CHECK (gender IN ('Monsieur', 'Madame')),
    birth_date DATE,
    personal_address VARCHAR(255),
    city VARCHAR(100),
    zip_code VARCHAR(10),
    mobile_phone VARCHAR(20),
    has_vehicle BOOLEAN DEFAULT FALSE,
    social_status VARCHAR(50) CHECK (social_status IN ('Salarié', 'Portage salarial', 'Indépendant ou société')),
    has_qualiopi BOOLEAN DEFAULT FALSE,
    has_nda BOOLEAN DEFAULT FALSE,
    website_url VARCHAR(255),
    bio TEXT,
    profile_photo_url VARCHAR(255),
    daily_rate_ht INTEGER,
    is_premium BOOLEAN DEFAULT FALSE,
    is_verified BOOLEAN DEFAULT FALSE,
    verification_date TIMESTAMP WITH TIME ZONE,
    profile_completion_percentage INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_trainers_city ON trainers(city);
CREATE INDEX idx_trainers_zip_code ON trainers(zip_code);
CREATE INDEX idx_trainers_is_verified ON trainers(is_verified);

-- ============================================================================
-- 3. TABLE ORGANISMES DE FORMATION (Profil spécifique lié à users)
-- ============================================================================
CREATE TABLE organizations (
    organization_id UUID PRIMARY KEY REFERENCES users(user_id) ON DELETE CASCADE,
    corporate_name VARCHAR(255) NOT NULL,
    siret VARCHAR(14) UNIQUE NOT NULL,
    website_url VARCHAR(255),
    professional_address VARCHAR(255),
    city VARCHAR(100),
    zip_code VARCHAR(10),
    mobile_phone VARCHAR(20),
    landline_phone VARCHAR(20),
    description TEXT,
    contact_person_first_name VARCHAR(100),
    contact_person_last_name VARCHAR(100),
    contact_person_civility VARCHAR(10) CHECK (contact_person_civility IN ('Monsieur', 'Madame')),
    contact_person_email VARCHAR(255),
    logo_url VARCHAR(255),
    is_verified BOOLEAN DEFAULT FALSE,
    verification_date TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_organizations_siret ON organizations(siret);
CREATE INDEX idx_organizations_city ON organizations(city);
CREATE INDEX idx_organizations_is_verified ON organizations(is_verified);

-- ============================================================================
-- 4. TABLE DES COMPÉTENCES DES FORMATEURS (Many-to-Many)
-- ============================================================================
CREATE TABLE trainer_skills (
    skill_id SERIAL PRIMARY KEY,
    trainer_id UUID NOT NULL REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    sphere VARCHAR(50) NOT NULL CHECK (sphere IN (
        'RH', 'Management', 'Bureautique', 'Digital', 'Communication', 
        'Langues', 'Bien-être', 'Métiers spécifiques'
    )),
    skill_level VARCHAR(50) NOT NULL CHECK (skill_level IN ('Débutant', 'Intermédiaire', 'Confirmé')),
    years_of_experience INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (trainer_id, sphere)
);

CREATE INDEX idx_trainer_skills_trainer_id ON trainer_skills(trainer_id);
CREATE INDEX idx_trainer_skills_sphere ON trainer_skills(sphere);

-- ============================================================================
-- 5. TABLE DU CATALOGUE DE FORMATIONS DU FORMATEUR
-- ============================================================================
CREATE TABLE trainer_catalogs (
    catalog_id SERIAL PRIMARY KEY,
    trainer_id UUID NOT NULL REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    training_title VARCHAR(255) NOT NULL,
    training_content TEXT NOT NULL,
    duration_hours INTEGER,
    target_audience TEXT,
    learning_objectives TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_trainer_catalogs_trainer_id ON trainer_catalogs(trainer_id);

-- ============================================================================
-- 6. TABLE DE MOBILITÉ (Many-to-Many)
-- ============================================================================
CREATE TABLE trainer_mobility (
    mobility_id SERIAL PRIMARY KEY,
    trainer_id UUID NOT NULL REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    area_code VARCHAR(10) NOT NULL,
    area_name VARCHAR(100),
    area_type VARCHAR(50) CHECK (area_type IN ('DEPARTMENT', 'REGION', 'COUNTRY', 'REMOTE')),
    UNIQUE (trainer_id, area_code)
);

CREATE INDEX idx_trainer_mobility_trainer_id ON trainer_mobility(trainer_id);
CREATE INDEX idx_trainer_mobility_area_code ON trainer_mobility(area_code);

-- ============================================================================
-- 7. TABLE DES MISSIONS (Publiées par les Organismes de Formation)
-- ============================================================================
CREATE TABLE missions (
    mission_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(organization_id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    location VARCHAR(100),
    required_skills TEXT,
    required_sphere VARCHAR(50) CHECK (required_sphere IN (
        'RH', 'Management', 'Bureautique', 'Digital', 'Communication', 
        'Langues', 'Bien-être', 'Métiers spécifiques'
    )),
    required_skill_level VARCHAR(50) CHECK (required_skill_level IN ('Débutant', 'Intermédiaire', 'Confirmé')),
    budget_min_ht INTEGER,
    budget_max_ht INTEGER,
    start_date DATE,
    end_date DATE,
    is_active BOOLEAN DEFAULT TRUE,
    is_data_paid BOOLEAN DEFAULT FALSE,
    published_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_missions_organization_id ON missions(organization_id);
CREATE INDEX idx_missions_required_sphere ON missions(required_sphere);
CREATE INDEX idx_missions_is_active ON missions(is_active);
CREATE INDEX idx_missions_published_at ON missions(published_at);

-- ============================================================================
-- 8. TABLE DE GESTION DES CRÉDITS (Suivi des crédits du formateur)
-- ============================================================================
CREATE TABLE trainer_credits (
    credit_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    trainer_id UUID NOT NULL REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    balance INTEGER NOT NULL DEFAULT 0,
    total_purchased INTEGER DEFAULT 0,
    total_used INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_trainer_credits_trainer_id ON trainer_credits(trainer_id);

-- ============================================================================
-- 9. TABLE DE GESTION DES PAIEMENTS (Modèle Pay-to-Reveal)
-- ============================================================================
CREATE TABLE payments (
    payment_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    payer_user_id UUID NOT NULL REFERENCES users(user_id),
    recipient_user_id UUID NOT NULL REFERENCES users(user_id),
    item_type VARCHAR(50) NOT NULL CHECK (item_type IN ('MESSAGE_REVEAL', 'MISSION_REVEAL', 'PROFILE_REVEAL')),
    item_id UUID,
    amount INTEGER NOT NULL DEFAULT 900,
    stripe_charge_id VARCHAR(255),
    stripe_payment_intent_id VARCHAR(255),
    status VARCHAR(50) DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED')),
    transaction_date TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    refund_date TIMESTAMP WITH TIME ZONE,
    refund_reason VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_payments_payer_user_id ON payments(payer_user_id);
CREATE INDEX idx_payments_recipient_user_id ON payments(recipient_user_id);
CREATE INDEX idx_payments_status ON payments(status);
CREATE INDEX idx_payments_transaction_date ON payments(transaction_date);

-- ============================================================================
-- 10. TABLE DE MESSAGERIE (Demandes de contact initiales)
-- ============================================================================
CREATE TABLE messages (
    message_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_user_id UUID REFERENCES users(user_id),
    sender_email VARCHAR(255),
    sender_name VARCHAR(255),
    recipient_trainer_id UUID NOT NULL REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    subject VARCHAR(255),
    full_content TEXT,
    is_revealed BOOLEAN DEFAULT FALSE,
    revealed_at TIMESTAMP WITH TIME ZONE,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP WITH TIME ZONE,
    sent_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_messages_recipient_trainer_id ON messages(recipient_trainer_id);
CREATE INDEX idx_messages_sender_user_id ON messages(sender_user_id);
CREATE INDEX idx_messages_is_revealed ON messages(is_revealed);
CREATE INDEX idx_messages_sent_at ON messages(sent_at);

-- ============================================================================
-- 11. TABLE DES RÉVÉLATIONS DE PROFIL (Historique des achats)
-- ============================================================================
CREATE TABLE profile_reveals (
    reveal_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    organization_id UUID NOT NULL REFERENCES organizations(organization_id) ON DELETE CASCADE,
    trainer_id UUID NOT NULL REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    payment_id UUID REFERENCES payments(payment_id),
    revealed_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (organization_id, trainer_id)
);

CREATE INDEX idx_profile_reveals_organization_id ON profile_reveals(organization_id);
CREATE INDEX idx_profile_reveals_trainer_id ON profile_reveals(trainer_id);

-- ============================================================================
-- 12. TABLE DE NOTIFICATIONS
-- ============================================================================
CREATE TABLE notifications (
    notification_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    notification_type VARCHAR(50) NOT NULL CHECK (notification_type IN (
        'NEW_MESSAGE', 'MESSAGE_REVEALED', 'NEW_MISSION', 'PAYMENT_RECEIVED', 
        'PROFILE_VIEWED', 'MISSION_MATCHED'
    )),
    title VARCHAR(255) NOT NULL,
    content TEXT,
    related_item_id UUID,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_created_at ON notifications(created_at);

-- ============================================================================
-- 13. TABLE DES FAVORIS (Bookmarks)
-- ============================================================================
CREATE TABLE favorites (
    favorite_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    favorite_type VARCHAR(50) NOT NULL CHECK (favorite_type IN ('TRAINER', 'MISSION')),
    favorite_item_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (user_id, favorite_type, favorite_item_id)
);

CREATE INDEX idx_favorites_user_id ON favorites(user_id);
CREATE INDEX idx_favorites_favorite_type ON favorites(favorite_type);

-- ============================================================================
-- 14. TABLE DES AVIS (Reviews/Ratings)
-- ============================================================================
CREATE TABLE reviews (
    review_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reviewer_user_id UUID NOT NULL REFERENCES users(user_id) ON DELETE CASCADE,
    trainer_id UUID NOT NULL REFERENCES trainers(trainer_id) ON DELETE CASCADE,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT,
    is_verified_purchase BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reviews_trainer_id ON reviews(trainer_id);
CREATE INDEX idx_reviews_reviewer_user_id ON reviews(reviewer_user_id);

-- ============================================================================
-- 15. TABLE D'AUDIT (Traçabilité)
-- ============================================================================
CREATE TABLE audit_logs (
    log_id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(user_id),
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_entity_type ON audit_logs(entity_type);
CREATE INDEX idx_audit_logs_created_at ON audit_logs(created_at);

-- ============================================================================
-- 16. TABLE DES TEMPLATES D'EMAIL
-- ============================================================================
CREATE TABLE email_templates (
    template_id SERIAL PRIMARY KEY,
    template_name VARCHAR(100) UNIQUE NOT NULL,
    subject VARCHAR(255) NOT NULL,
    html_content TEXT NOT NULL,
    text_content TEXT,
    variables JSONB,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================================
-- VUES MATÉRIALISÉES POUR LES RECHERCHES COMPLEXES
-- ============================================================================

-- Vue pour les formateurs avec leurs compétences et mobilité
CREATE VIEW trainer_profiles_view AS
SELECT 
    t.trainer_id,
    u.email,
    t.first_name,
    t.last_name,
    t.city,
    t.zip_code,
    t.daily_rate_ht,
    t.is_verified,
    t.profile_photo_url,
    json_agg(DISTINCT jsonb_build_object(
        'sphere', ts.sphere,
        'level', ts.skill_level
    )) as skills,
    json_agg(DISTINCT jsonb_build_object(
        'area_code', tm.area_code,
        'area_name', tm.area_name
    )) as mobility_areas,
    COUNT(DISTINCT r.review_id) as review_count,
    AVG(r.rating) as average_rating
FROM trainers t
JOIN users u ON t.trainer_id = u.user_id
LEFT JOIN trainer_skills ts ON t.trainer_id = ts.trainer_id
LEFT JOIN trainer_mobility tm ON t.trainer_id = tm.trainer_id
LEFT JOIN reviews r ON t.trainer_id = r.trainer_id
WHERE u.is_active = TRUE AND u.is_deleted = FALSE
GROUP BY t.trainer_id, u.email, t.first_name, t.last_name, t.city, t.zip_code, t.daily_rate_ht, t.is_verified, t.profile_photo_url;

-- Vue pour les missions avec les détails de l'organisation
CREATE VIEW missions_view AS
SELECT 
    m.mission_id,
    m.title,
    m.description,
    m.location,
    m.required_sphere,
    m.required_skill_level,
    m.budget_min_ht,
    m.budget_max_ht,
    m.start_date,
    m.end_date,
    m.is_active,
    o.corporate_name,
    o.city as organization_city,
    COUNT(DISTINCT msg.message_id) as application_count
FROM missions m
JOIN organizations o ON m.organization_id = o.organization_id
LEFT JOIN messages msg ON m.mission_id = msg.message_id
WHERE m.is_active = TRUE
GROUP BY m.mission_id, m.title, m.description, m.location, m.required_sphere, 
         m.required_skill_level, m.budget_min_ht, m.budget_max_ht, m.start_date, 
         m.end_date, m.is_active, o.corporate_name, o.city;

-- ============================================================================
-- TRIGGERS POUR LA GESTION AUTOMATIQUE
-- ============================================================================

-- Trigger pour mettre à jour updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_trainers_updated_at BEFORE UPDATE ON trainers
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_organizations_updated_at BEFORE UPDATE ON organizations
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_messages_updated_at BEFORE UPDATE ON messages
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON payments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Trigger pour initialiser les crédits lors de la création d'un formateur
CREATE OR REPLACE FUNCTION initialize_trainer_credits()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO trainer_credits (trainer_id, balance, total_purchased, total_used)
    VALUES (NEW.trainer_id, 0, 0, 0);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER init_credits_on_trainer_create AFTER INSERT ON trainers
    FOR EACH ROW EXECUTE FUNCTION initialize_trainer_credits();

-- ============================================================================
-- DONNÉES INITIALES (Templates d'email)
-- ============================================================================

INSERT INTO email_templates (template_name, subject, html_content, text_content) VALUES
('welcome_trainer', 'Bienvenue sur Annuaire Formateur', 
'<h1>Bienvenue {{first_name}} !</h1><p>Votre profil de formateur a été créé avec succès.</p>',
'Bienvenue {{first_name}} ! Votre profil de formateur a été créé avec succès.'),

('welcome_organization', 'Bienvenue sur Annuaire Formateur', 
'<h1>Bienvenue {{corporate_name}} !</h1><p>Votre compte organisateur a été créé avec succès.</p>',
'Bienvenue {{corporate_name}} ! Votre compte organisateur a été créé avec succès.'),

('new_message_notification', 'Nouvelle opportunité pour vous !', 
'<h1>Une nouvelle opportunité vous attend !</h1><p>{{sender_name}} s''intéresse à votre profil.</p>',
'Une nouvelle opportunité vous attend ! {{sender_name}} s''intéresse à votre profil.'),

('payment_confirmation', 'Paiement confirmé', 
'<h1>Paiement reçu</h1><p>Votre paiement de {{amount}} € a été traité avec succès.</p>',
'Paiement reçu. Votre paiement de {{amount}} € a été traité avec succès.');
