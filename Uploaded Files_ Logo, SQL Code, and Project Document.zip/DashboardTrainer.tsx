import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Lock, Mail, MapPin, Briefcase, User, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function DashboardTrainer() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  const { data: profile } = trpc.profile.getMyProfile.useQuery();
  const { data: messages = [] } = trpc.messages.getMyMessages.useQuery();
  const { data: missions = [] } = trpc.missions.getActiveMissions.useQuery();
  const { data: notifications = [] } = trpc.notifications.getMyNotifications.useQuery();
  const { data: unreadCount = 0 } = trpc.notifications.getUnreadCount.useQuery();

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      logout();
      setLocation("/");
      toast.success("Déconnexion réussie");
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleUnlockMessage = async (messageId: number) => {
    // This would create a payment intent and redirect to Stripe
    toast.info("Redirection vers le paiement...");
    // In a real implementation, we would call the payment mutation here
  };

  const trainer = profile?.type === "trainer" ? profile.trainer : null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src="/logo.png" alt="Annuaire Formateur" className="h-10 w-10" />
              <div>
                <h1 className="text-xl font-bold text-primary">Annuaire Formateur</h1>
                <p className="text-sm text-muted-foreground">Dashboard Formateur</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" className="relative">
                <Bell className="h-5 w-5" />
                {unreadCount > 0 && (
                  <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-destructive text-destructive-foreground">
                    {unreadCount}
                  </Badge>
                )}
              </Button>
              <div className="flex items-center gap-2">
                <User className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm">{user?.name}</span>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Déconnexion
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-primary mb-2">
            Bienvenue, {trainer?.firstName} {trainer?.lastName}
          </h2>
          <p className="text-muted-foreground">Gérez vos opportunités et votre profil depuis votre dashboard</p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-6 md:grid-cols-3 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Messages reçus</CardTitle>
              <Mail className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{messages.length}</div>
              <p className="text-xs text-muted-foreground">
                {messages.filter((m) => !m.isRevealed).length} non débloqués
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Missions disponibles</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{missions.length}</div>
              <p className="text-xs text-muted-foreground">Missions actives</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Complétion du profil</CardTitle>
              <User className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{trainer?.profileCompletionPercentage || 0}%</div>
              <p className="text-xs text-muted-foreground">Complétez pour plus de visibilité</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="opportunities" className="space-y-4">
          <TabsList>
            <TabsTrigger value="opportunities">Mes Opportunités</TabsTrigger>
            <TabsTrigger value="missions">Missions Disponibles</TabsTrigger>
            <TabsTrigger value="profile">Mon Profil</TabsTrigger>
          </TabsList>

          {/* Mes Opportunités */}
          <TabsContent value="opportunities" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Mes Opportunités</CardTitle>
                <CardDescription>
                  Messages et propositions reçus des organismes de formation. Débloquez pour 9€ pour voir les
                  coordonnées complètes.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {messages.length === 0 ? (
                  <div className="text-center py-12">
                    <Mail className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">Aucune opportunité pour le moment</p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Complétez votre profil pour augmenter vos chances de recevoir des propositions
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <Card key={message.id} className="relative">
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <CardTitle className="text-lg flex items-center gap-2">
                                {message.subject}
                                {!message.isRevealed && (
                                  <Badge variant="secondary" className="bg-accent text-accent-foreground">
                                    <Lock className="h-3 w-3 mr-1" />
                                    Verrouillé
                                  </Badge>
                                )}
                                {message.isRevealed && (
                                  <Badge variant="secondary" className="bg-secondary text-secondary-foreground">
                                    Débloqué
                                  </Badge>
                                )}
                              </CardTitle>
                              <CardDescription>
                                De: {message.senderName} • {new Date(message.sentAt).toLocaleDateString("fr-FR")}
                              </CardDescription>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <div className={message.isRevealed ? "" : "blur-sm select-none"}>
                            <p className="text-sm mb-4">{message.fullContent}</p>
                            {message.isRevealed && (
                              <div className="space-y-1 text-sm">
                                <p>
                                  <strong>Email:</strong> {message.senderEmail}
                                </p>
                              </div>
                            )}
                          </div>
                          {!message.isRevealed && (
                            <div className="mt-4">
                              <Button
                                className="bg-accent text-accent-foreground hover:bg-accent/90"
                                onClick={() => handleUnlockMessage(message.id)}
                              >
                                <Lock className="h-4 w-4 mr-2" />
                                Débloquer ce contact pour 9€
                              </Button>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Missions Disponibles */}
          <TabsContent value="missions" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Missions Disponibles</CardTitle>
                <CardDescription>Découvrez les missions publiées par les organismes de formation</CardDescription>
              </CardHeader>
              <CardContent>
                {missions.length === 0 ? (
                  <div className="text-center py-12">
                    <Briefcase className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground">Aucune mission disponible pour le moment</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {missions.map((mission) => (
                      <Card key={mission.id}>
                        <CardHeader>
                          <CardTitle className="text-lg">{mission.title}</CardTitle>
                          <CardDescription className="flex items-center gap-2">
                            <MapPin className="h-4 w-4" />
                            {mission.location || "Non spécifié"} • {mission.organization?.corporateName}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm mb-4">{mission.description}</p>
                          <div className="flex items-center gap-2">
                            {mission.requiredSphere && <Badge variant="secondary">{mission.requiredSphere}</Badge>}
                            {mission.requiredSkillLevel && <Badge variant="outline">{mission.requiredSkillLevel}</Badge>}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mon Profil */}
          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Mon Profil</CardTitle>
                <CardDescription>Informations visibles par les organismes de formation</CardDescription>
              </CardHeader>
              <CardContent>
                {trainer && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Informations personnelles</h4>
                      <p className="text-sm">
                        {trainer.gender} {trainer.firstName} {trainer.lastName}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {trainer.city}, {trainer.zipCode}
                      </p>
                    </div>

                    {trainer.bio && (
                      <div>
                        <h4 className="font-semibold mb-2">Bio</h4>
                        <p className="text-sm text-muted-foreground">{trainer.bio}</p>
                      </div>
                    )}

                    <div>
                      <h4 className="font-semibold mb-2">Tarif journalier</h4>
                      <p className="text-sm">{trainer.dailyRateHt ? `${trainer.dailyRateHt}€ HT/jour` : "Non renseigné"}</p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">Certifications</h4>
                      <div className="flex gap-2">
                        {trainer.hasQualiopi && <Badge>Qualiopi</Badge>}
                        {trainer.hasNda && <Badge>NDA</Badge>}
                        {trainer.hasVehicle && <Badge variant="outline">Véhiculé</Badge>}
                      </div>
                    </div>

                    <Button variant="outline" onClick={() => setLocation("/profile/edit")}>
                      Modifier mon profil
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
