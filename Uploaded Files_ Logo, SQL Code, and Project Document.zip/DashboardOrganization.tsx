import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, Briefcase, Search, LogOut, Plus } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

export default function DashboardOrganization() {
  const { user, logout } = useAuth();
  const [, setLocation] = useLocation();

  const { data: profile } = trpc.profile.getMyProfile.useQuery();
  const { data: missions = [] } = trpc.missions.getMyMissions.useQuery();

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      logout();
      setLocation("/");
      toast.success("Déconnexion réussie");
    },
  });

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const organization = profile?.type === "organization" ? profile.organization : null;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src="/logo.png" alt="Annuaire Formateur" className="h-10 w-10" />
              <div>
                <h1 className="text-xl font-bold text-primary">Annuaire Formateur</h1>
                <p className="text-sm text-muted-foreground">Dashboard Organisme</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Briefcase className="h-5 w-5 text-muted-foreground" />
                <span className="text-sm">{organization?.corporateName}</span>
              </div>
              <Button variant="outline" size="sm" onClick={handleLogout}>
                <LogOut className="h-4 w-4 mr-2" />
                Déconnexion
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-primary mb-2">Bienvenue, {organization?.corporateName}</h2>
          <p className="text-muted-foreground">
            Recherchez des formateurs et gérez vos missions depuis votre dashboard
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-6 md:grid-cols-3 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Missions actives</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{missions.filter((m) => m.isActive).length}</div>
              <p className="text-xs text-muted-foreground">Missions publiées</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total missions</CardTitle>
              <Briefcase className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{missions.length}</div>
              <p className="text-xs text-muted-foreground">Toutes les missions</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Formateurs</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">-</div>
              <p className="text-xs text-muted-foreground">Contactés</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="search" className="space-y-4">
          <TabsList>
            <TabsTrigger value="search">Rechercher des Formateurs</TabsTrigger>
            <TabsTrigger value="missions">Mes Missions</TabsTrigger>
            <TabsTrigger value="profile">Mon Profil</TabsTrigger>
          </TabsList>

          {/* Rechercher des Formateurs */}
          <TabsContent value="search" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Rechercher des Formateurs</CardTitle>
                    <CardDescription>
                      Trouvez le formateur idéal grâce à nos filtres de recherche par compétence, localisation et
                      tarif
                    </CardDescription>
                  </div>
                  <Button variant="outline">
                    <Search className="h-4 w-4 mr-2" />
                    Recherche avancée
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Users className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground mb-4">
                    Utilisez les filtres pour trouver des formateurs correspondant à vos besoins
                  </p>
                  <Button onClick={() => toast.info("Fonctionnalité de recherche à venir")}>
                    Lancer une recherche
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mes Missions */}
          <TabsContent value="missions" className="space-y-4">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Mes Missions</CardTitle>
                    <CardDescription>Gérez vos missions publiées et créez-en de nouvelles</CardDescription>
                  </div>
                  <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                    <Plus className="h-4 w-4 mr-2" />
                    Publier une mission
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {missions.length === 0 ? (
                  <div className="text-center py-12">
                    <Briefcase className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                    <p className="text-muted-foreground mb-4">Vous n'avez pas encore publié de mission</p>
                    <Button className="bg-accent text-accent-foreground hover:bg-accent/90">
                      <Plus className="h-4 w-4 mr-2" />
                      Publier ma première mission
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {missions.map((mission) => (
                      <Card key={mission.id}>
                        <CardHeader>
                          <div className="flex items-start justify-between">
                            <div>
                              <CardTitle className="text-lg">{mission.title}</CardTitle>
                              <CardDescription>
                                Publié le {new Date(mission.publishedAt).toLocaleDateString("fr-FR")}
                              </CardDescription>
                            </div>
                            <Button variant="outline" size="sm">
                              Modifier
                            </Button>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">{mission.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Mon Profil */}
          <TabsContent value="profile" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Mon Profil</CardTitle>
                <CardDescription>Informations de votre organisme</CardDescription>
              </CardHeader>
              <CardContent>
                {organization && (
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold mb-2">Raison sociale</h4>
                      <p className="text-sm">{organization.corporateName}</p>
                    </div>

                    <div>
                      <h4 className="font-semibold mb-2">SIRET</h4>
                      <p className="text-sm">{organization.siret}</p>
                    </div>

                    {organization.city && (
                      <div>
                        <h4 className="font-semibold mb-2">Localisation</h4>
                        <p className="text-sm">
                          {organization.city}, {organization.zipCode}
                        </p>
                      </div>
                    )}

                    {organization.description && (
                      <div>
                        <h4 className="font-semibold mb-2">Description</h4>
                        <p className="text-sm text-muted-foreground">{organization.description}</p>
                      </div>
                    )}

                    {organization.contactPersonFirstName && (
                      <div>
                        <h4 className="font-semibold mb-2">Personne de contact</h4>
                        <p className="text-sm">
                          {organization.contactPersonCivility} {organization.contactPersonFirstName}{" "}
                          {organization.contactPersonLastName}
                        </p>
                        {organization.contactPersonEmail && (
                          <p className="text-sm text-muted-foreground">{organization.contactPersonEmail}</p>
                        )}
                      </div>
                    )}

                    <Button variant="outline">Modifier mon profil</Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
