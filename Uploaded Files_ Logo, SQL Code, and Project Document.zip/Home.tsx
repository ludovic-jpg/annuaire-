import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, MapPin, Users, Briefcase, Lock, Zap, CheckCircle } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      {/* Header / Navigation */}
      <header className="border-b border-border bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img src="/logo.png" alt="Annuaire Formateur" className="h-12 w-12" />
              <h1 className="text-2xl font-bold text-primary">Annuaire Formateur</h1>
            </div>
            <div className="flex items-center gap-4">
              {isAuthenticated ? (
                <>
                  <span className="text-sm text-muted-foreground">Bonjour, {user?.name}</span>
                  <Link href="/dashboard">
                    <Button variant="default">Mon Dashboard</Button>
                  </Link>
                </>
              ) : (
                <>
                  <a href={getLoginUrl()}>
                    <Button variant="outline">Se connecter</Button>
                  </a>
                  <a href={getLoginUrl()}>
                    <Button variant="default" className="bg-accent text-accent-foreground hover:bg-accent/90">
                      S'inscrire
                    </Button>
                  </a>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary to-secondary py-20 text-primary-foreground">
        <div className="container mx-auto px-4 text-center">
          <h2 className="mb-6 text-5xl font-bold">
            La Rencontre Parfaite entre Formateurs et Organismes de Formation
          </h2>
          <p className="mb-8 text-xl opacity-90">
            Votre Prochaine Mission de Formation Commence Ici. Le Réseau N°1 pour les Professionnels de la Formation.
          </p>
          <div className="flex justify-center gap-4">
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                Créer mon profil de formateur
              </Button>
            </a>
            <a href={getLoginUrl()}>
              <Button size="lg" variant="outline" className="border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary">
                Publier une mission (gratuit)
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Pour les Formateurs */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h3 className="mb-4 text-4xl font-bold text-primary">Vous êtes Formateur ?</h3>
            <p className="text-xl text-muted-foreground">
              Transformez Votre Expertise en Opportunités Concrètes. Ne Cherchez Plus de Clients. Laissez-les Venir à
              Vous.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            <Card>
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Visibilité Maximale</CardTitle>
                <CardDescription>
                  Votre profil est consulté par des décisionnaires qui ont un besoin réel et immédiat.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Créez votre profil expert en quelques minutes</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Mettez en avant vos compétences et certifications</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Catalogue de formations personnalisé</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-secondary/10">
                  <Zap className="h-6 w-6 text-secondary" />
                </div>
                <CardTitle>Opportunités Ciblées</CardTitle>
                <CardDescription>
                  Recevez des notifications pour des missions qui correspondent précisément à votre profil.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Alertes en temps réel par email et dashboard</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Missions adaptées à votre localisation</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Filtrage par domaine d'expertise</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10">
                  <Lock className="h-6 w-6 text-accent-foreground" />
                </div>
                <CardTitle>Monétisation Juste</CardTitle>
                <CardDescription>
                  Pas d'abonnement. Un paiement unique de 9€ pour débloquer une conversation qualifiée.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Payez uniquement pour les opportunités qui vous intéressent</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Accès complet aux coordonnées de l'organisme</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="mt-0.5 h-4 w-4 text-secondary" />
                    <span>Paiement sécurisé via Stripe</span>
                  </li>
                </ul>
              </CardContent>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <a href={getLoginUrl()}>
              <Button size="lg" className="bg-accent text-accent-foreground hover:bg-accent/90">
                S'inscrire et trouver ma première mission
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Pour les Organismes de Formation */}
      <section className="bg-muted py-16">
        <div className="container mx-auto px-4">
          <div className="mb-12 text-center">
            <h3 className="mb-4 text-4xl font-bold text-primary">Vous êtes un Organisme de Formation ?</h3>
            <p className="text-xl text-muted-foreground">
              Le Formateur Idéal pour Votre Projet, Disponible et Qualifié. Recrutez des Formateurs Experts en Moins de
              48h.
            </p>
          </div>

          <div className="grid gap-8 md:grid-cols-3">
            <Card>
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Gratuité Totale</CardTitle>
                <CardDescription>
                  Publiez autant de missions que vous le souhaitez et contactez les formateurs sans aucun coût.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-secondary/10">
                  <MapPin className="h-6 w-6 text-secondary" />
                </div>
                <CardTitle>Gain de Temps</CardTitle>
                <CardDescription>
                  Un moteur de recherche puissant pour filtrer par compétence, tarif, et localisation.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-accent/10">
                  <Briefcase className="h-6 w-6 text-accent-foreground" />
                </div>
                <CardTitle>Qualité Garantie</CardTitle>
                <CardDescription>
                  Accédez à des profils vérifiés avec des informations complètes (bio, catalogue de formations, etc.).
                </CardDescription>
              </CardHeader>
            </Card>
          </div>

          <div className="mt-12 text-center">
            <a href={getLoginUrl()}>
              <Button size="lg" variant="default">
                Publier une mission gratuitement
              </Button>
            </a>
          </div>
        </div>
      </section>

      {/* Comment ça marche */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h3 className="mb-12 text-center text-4xl font-bold text-primary">Comment ça marche ?</h3>

          <div className="grid gap-12 md:grid-cols-2">
            {/* Pour les Formateurs */}
            <div>
              <h4 className="mb-6 text-2xl font-bold text-secondary">Pour les Formateurs</h4>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    1
                  </div>
                  <div>
                    <h5 className="mb-2 font-semibold">Créez votre profil expert</h5>
                    <p className="text-sm text-muted-foreground">
                      Remplissez vos informations, vos compétences et votre catalogue de formations pour être visible.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    2
                  </div>
                  <div>
                    <h5 className="mb-2 font-semibold">Recevez des alertes</h5>
                    <p className="text-sm text-muted-foreground">
                      Soyez notifié en temps réel lorsqu'un organisme s'intéresse à votre profil ou publie une mission
                      qui vous correspond.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                    3
                  </div>
                  <div>
                    <h5 className="mb-2 font-semibold">Débloquez les opportunités</h5>
                    <p className="text-sm text-muted-foreground">
                      Pour 9€, accédez aux coordonnées complètes de l'organisme et ouvrez la discussion pour finaliser
                      la mission.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Pour les OF */}
            <div>
              <h4 className="mb-6 text-2xl font-bold text-secondary">Pour les Organismes de Formation</h4>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    1
                  </div>
                  <div>
                    <h5 className="mb-2 font-semibold">Inscrivez-vous gratuitement</h5>
                    <p className="text-sm text-muted-foreground">
                      Créez votre compte en 2 minutes pour accéder à notre base de données de formateurs.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-primary text-primary-foreground">
                    2
                  </div>
                  <div>
                    <h5 className="mb-2 font-semibold">Recherchez ou publiez</h5>
                    <p className="text-sm text-muted-foreground">
                      Trouvez le profil idéal grâce à nos filtres de recherche ou publiez une mission pour recevoir des
                      candidatures.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
                    3
                  </div>
                  <div>
                    <h5 className="mb-2 font-semibold">Contactez sans frais</h5>
                    <p className="text-sm text-muted-foreground">
                      Envoyez des propositions directement aux formateurs via notre messagerie interne sécurisée.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>&copy; 2025 Annuaire Formateur. Tous droits réservés.</p>
        </div>
      </footer>
    </div>
  );
}
