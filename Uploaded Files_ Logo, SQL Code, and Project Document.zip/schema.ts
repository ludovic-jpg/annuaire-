import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, index, unique } from "drizzle-orm/mysql-core";

/**
 * SCHEMA MULTIDIRECTORY - "ANNUAIRE FORMATEUR"
 * Plateforme de mise en relation entre Formateurs et Organismes de Formation
 * Modèle économique : Pay-to-Reveal (Formateur paie pour débloquer les contacts)
 */

// ============================================================================
// 1. TABLE DES UTILISATEURS PRINCIPAUX
// ============================================================================
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["trainer", "organization", "admin"]).default("trainer").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  emailVerified: boolean("emailVerified").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (table) => ({
  roleIdx: index("role_idx").on(table.role),
  isActiveIdx: index("is_active_idx").on(table.isActive),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ============================================================================
// 2. TABLE FORMATEURS (Profil spécifique lié à users)
// ============================================================================
export const trainers = mysqlTable("trainers", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  firstName: varchar("firstName", { length: 100 }).notNull(),
  lastName: varchar("lastName", { length: 100 }).notNull(),
  gender: mysqlEnum("gender", ["Monsieur", "Madame"]),
  birthDate: timestamp("birthDate"),
  personalAddress: text("personalAddress"),
  city: varchar("city", { length: 100 }),
  zipCode: varchar("zipCode", { length: 10 }),
  mobilePhone: varchar("mobilePhone", { length: 20 }),
  hasVehicle: boolean("hasVehicle").default(false),
  socialStatus: mysqlEnum("socialStatus", ["Salarié", "Portage salarial", "Indépendant ou société"]),
  hasQualiopi: boolean("hasQualiopi").default(false),
  hasNda: boolean("hasNda").default(false),
  websiteUrl: varchar("websiteUrl", { length: 255 }),
  bio: text("bio"),
  profilePhotoUrl: varchar("profilePhotoUrl", { length: 500 }),
  dailyRateHt: int("dailyRateHt"),
  isPremium: boolean("isPremium").default(false),
  isVerified: boolean("isVerified").default(false),
  profileCompletionPercentage: int("profileCompletionPercentage").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("trainer_user_id_idx").on(table.userId),
  cityIdx: index("trainer_city_idx").on(table.city),
  zipCodeIdx: index("trainer_zip_code_idx").on(table.zipCode),
  isVerifiedIdx: index("trainer_is_verified_idx").on(table.isVerified),
  userIdUnique: unique("trainer_user_id_unique").on(table.userId),
}));

export type Trainer = typeof trainers.$inferSelect;
export type InsertTrainer = typeof trainers.$inferInsert;

// ============================================================================
// 3. TABLE ORGANISMES DE FORMATION
// ============================================================================
export const organizations = mysqlTable("organizations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  corporateName: varchar("corporateName", { length: 255 }).notNull(),
  siret: varchar("siret", { length: 14 }).notNull(),
  websiteUrl: varchar("websiteUrl", { length: 255 }),
  professionalAddress: text("professionalAddress"),
  city: varchar("city", { length: 100 }),
  zipCode: varchar("zipCode", { length: 10 }),
  mobilePhone: varchar("mobilePhone", { length: 20 }),
  landlinePhone: varchar("landlinePhone", { length: 20 }),
  description: text("description"),
  contactPersonFirstName: varchar("contactPersonFirstName", { length: 100 }),
  contactPersonLastName: varchar("contactPersonLastName", { length: 100 }),
  contactPersonCivility: mysqlEnum("contactPersonCivility", ["Monsieur", "Madame"]),
  contactPersonEmail: varchar("contactPersonEmail", { length: 320 }),
  logoUrl: varchar("logoUrl", { length: 500 }),
  isVerified: boolean("isVerified").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  userIdIdx: index("org_user_id_idx").on(table.userId),
  siretIdx: index("org_siret_idx").on(table.siret),
  cityIdx: index("org_city_idx").on(table.city),
  isVerifiedIdx: index("org_is_verified_idx").on(table.isVerified),
  userIdUnique: unique("org_user_id_unique").on(table.userId),
  siretUnique: unique("org_siret_unique").on(table.siret),
}));

export type Organization = typeof organizations.$inferSelect;
export type InsertOrganization = typeof organizations.$inferInsert;

// ============================================================================
// 4. TABLE DES COMPÉTENCES DES FORMATEURS
// ============================================================================
export const trainerSkills = mysqlTable("trainerSkills", {
  id: int("id").autoincrement().primaryKey(),
  trainerId: int("trainerId").notNull().references(() => trainers.id, { onDelete: "cascade" }),
  sphere: mysqlEnum("sphere", [
    "RH", "Management", "Bureautique", "Digital", "Communication",
    "Langues", "Bien-être", "Métiers spécifiques"
  ]).notNull(),
  skillLevel: mysqlEnum("skillLevel", ["Débutant", "Intermédiaire", "Confirmé"]).notNull(),
  yearsOfExperience: int("yearsOfExperience"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  trainerIdIdx: index("skill_trainer_id_idx").on(table.trainerId),
  sphereIdx: index("skill_sphere_idx").on(table.sphere),
  trainerSphereUnique: unique("trainer_sphere_unique").on(table.trainerId, table.sphere),
}));

export type TrainerSkill = typeof trainerSkills.$inferSelect;
export type InsertTrainerSkill = typeof trainerSkills.$inferInsert;

// ============================================================================
// 5. TABLE DU CATALOGUE DE FORMATIONS
// ============================================================================
export const trainerCatalogs = mysqlTable("trainerCatalogs", {
  id: int("id").autoincrement().primaryKey(),
  trainerId: int("trainerId").notNull().references(() => trainers.id, { onDelete: "cascade" }),
  trainingTitle: varchar("trainingTitle", { length: 255 }).notNull(),
  trainingContent: text("trainingContent").notNull(),
  durationHours: int("durationHours"),
  targetAudience: text("targetAudience"),
  learningObjectives: text("learningObjectives"),
  isActive: boolean("isActive").default(true),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  trainerIdIdx: index("catalog_trainer_id_idx").on(table.trainerId),
}));

export type TrainerCatalog = typeof trainerCatalogs.$inferSelect;
export type InsertTrainerCatalog = typeof trainerCatalogs.$inferInsert;

// ============================================================================
// 6. TABLE DE MOBILITÉ
// ============================================================================
export const trainerMobility = mysqlTable("trainerMobility", {
  id: int("id").autoincrement().primaryKey(),
  trainerId: int("trainerId").notNull().references(() => trainers.id, { onDelete: "cascade" }),
  areaCode: varchar("areaCode", { length: 10 }).notNull(),
  areaName: varchar("areaName", { length: 100 }),
  areaType: mysqlEnum("areaType", ["DEPARTMENT", "REGION", "COUNTRY", "REMOTE"]),
}, (table) => ({
  trainerIdIdx: index("mobility_trainer_id_idx").on(table.trainerId),
  areaCodeIdx: index("mobility_area_code_idx").on(table.areaCode),
  trainerAreaUnique: unique("trainer_area_unique").on(table.trainerId, table.areaCode),
}));

export type TrainerMobility = typeof trainerMobility.$inferSelect;
export type InsertTrainerMobility = typeof trainerMobility.$inferInsert;

// ============================================================================
// 7. TABLE DES MISSIONS
// ============================================================================
export const missions = mysqlTable("missions", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  location: varchar("location", { length: 100 }),
  requiredSkills: text("requiredSkills"),
  requiredSphere: mysqlEnum("requiredSphere", [
    "RH", "Management", "Bureautique", "Digital", "Communication",
    "Langues", "Bien-être", "Métiers spécifiques"
  ]),
  requiredSkillLevel: mysqlEnum("requiredSkillLevel", ["Débutant", "Intermédiaire", "Confirmé"]),
  budgetMinHt: int("budgetMinHt"),
  budgetMaxHt: int("budgetMaxHt"),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  isActive: boolean("isActive").default(true),
  publishedAt: timestamp("publishedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  organizationIdIdx: index("mission_org_id_idx").on(table.organizationId),
  requiredSphereIdx: index("mission_sphere_idx").on(table.requiredSphere),
  isActiveIdx: index("mission_is_active_idx").on(table.isActive),
  publishedAtIdx: index("mission_published_at_idx").on(table.publishedAt),
}));

export type Mission = typeof missions.$inferSelect;
export type InsertMission = typeof missions.$inferInsert;

// ============================================================================
// 8. TABLE DE GESTION DES CRÉDITS
// ============================================================================
export const trainerCredits = mysqlTable("trainerCredits", {
  id: int("id").autoincrement().primaryKey(),
  trainerId: int("trainerId").notNull().references(() => trainers.id, { onDelete: "cascade" }),
  balance: int("balance").notNull().default(0),
  totalPurchased: int("totalPurchased").default(0),
  totalUsed: int("totalUsed").default(0),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  trainerIdIdx: index("credits_trainer_id_idx").on(table.trainerId),
  trainerIdUnique: unique("credits_trainer_id_unique").on(table.trainerId),
}));

export type TrainerCredit = typeof trainerCredits.$inferSelect;
export type InsertTrainerCredit = typeof trainerCredits.$inferInsert;

// ============================================================================
// 9. TABLE DE GESTION DES PAIEMENTS
// ============================================================================
export const payments = mysqlTable("payments", {
  id: int("id").autoincrement().primaryKey(),
  payerUserId: int("payerUserId").notNull().references(() => users.id),
  recipientUserId: int("recipientUserId").references(() => users.id),
  itemType: mysqlEnum("itemType", ["MESSAGE_REVEAL", "MISSION_REVEAL", "PROFILE_REVEAL"]).notNull(),
  itemId: int("itemId"),
  amount: int("amount").notNull().default(900), // 9€ en centimes
  stripeChargeId: varchar("stripeChargeId", { length: 255 }),
  stripePaymentIntentId: varchar("stripePaymentIntentId", { length: 255 }),
  status: mysqlEnum("status", ["PENDING", "COMPLETED", "FAILED", "REFUNDED"]).default("PENDING"),
  transactionDate: timestamp("transactionDate").defaultNow().notNull(),
  refundDate: timestamp("refundDate"),
  refundReason: varchar("refundReason", { length: 255 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  payerUserIdIdx: index("payment_payer_id_idx").on(table.payerUserId),
  recipientUserIdIdx: index("payment_recipient_id_idx").on(table.recipientUserId),
  statusIdx: index("payment_status_idx").on(table.status),
  transactionDateIdx: index("payment_transaction_date_idx").on(table.transactionDate),
}));

export type Payment = typeof payments.$inferSelect;
export type InsertPayment = typeof payments.$inferInsert;

// ============================================================================
// 10. TABLE DE MESSAGERIE
// ============================================================================
export const messages = mysqlTable("messages", {
  id: int("id").autoincrement().primaryKey(),
  senderUserId: int("senderUserId").references(() => users.id),
  senderEmail: varchar("senderEmail", { length: 320 }),
  senderName: varchar("senderName", { length: 255 }),
  recipientTrainerId: int("recipientTrainerId").notNull().references(() => trainers.id, { onDelete: "cascade" }),
  subject: varchar("subject", { length: 255 }),
  fullContent: text("fullContent"),
  missionId: int("missionId").references(() => missions.id),
  isRevealed: boolean("isRevealed").default(false),
  revealedAt: timestamp("revealedAt"),
  isRead: boolean("isRead").default(false),
  readAt: timestamp("readAt"),
  sentAt: timestamp("sentAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  recipientTrainerIdIdx: index("message_recipient_trainer_id_idx").on(table.recipientTrainerId),
  senderUserIdIdx: index("message_sender_user_id_idx").on(table.senderUserId),
  isRevealedIdx: index("message_is_revealed_idx").on(table.isRevealed),
  sentAtIdx: index("message_sent_at_idx").on(table.sentAt),
}));

export type Message = typeof messages.$inferSelect;
export type InsertMessage = typeof messages.$inferInsert;

// ============================================================================
// 11. TABLE DES RÉVÉLATIONS DE PROFIL
// ============================================================================
export const profileReveals = mysqlTable("profileReveals", {
  id: int("id").autoincrement().primaryKey(),
  organizationId: int("organizationId").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  trainerId: int("trainerId").notNull().references(() => trainers.id, { onDelete: "cascade" }),
  paymentId: int("paymentId").references(() => payments.id),
  revealedAt: timestamp("revealedAt").defaultNow().notNull(),
}, (table) => ({
  organizationIdIdx: index("reveal_org_id_idx").on(table.organizationId),
  trainerIdIdx: index("reveal_trainer_id_idx").on(table.trainerId),
  orgTrainerUnique: unique("reveal_org_trainer_unique").on(table.organizationId, table.trainerId),
}));

export type ProfileReveal = typeof profileReveals.$inferSelect;
export type InsertProfileReveal = typeof profileReveals.$inferInsert;

// ============================================================================
// 12. TABLE DE NOTIFICATIONS
// ============================================================================
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  notificationType: mysqlEnum("notificationType", [
    "NEW_MESSAGE", "MESSAGE_REVEALED", "NEW_MISSION", "PAYMENT_RECEIVED",
    "PROFILE_VIEWED", "MISSION_MATCHED"
  ]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: text("content"),
  relatedItemId: int("relatedItemId"),
  isRead: boolean("isRead").default(false),
  readAt: timestamp("readAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("notif_user_id_idx").on(table.userId),
  isReadIdx: index("notif_is_read_idx").on(table.isRead),
  createdAtIdx: index("notif_created_at_idx").on(table.createdAt),
}));

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ============================================================================
// 13. TABLE DES FAVORIS
// ============================================================================
export const favorites = mysqlTable("favorites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  favoriteType: mysqlEnum("favoriteType", ["TRAINER", "MISSION"]).notNull(),
  favoriteItemId: int("favoriteItemId").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdIdx: index("fav_user_id_idx").on(table.userId),
  favoriteTypeIdx: index("fav_type_idx").on(table.favoriteType),
  userTypeFavUnique: unique("fav_user_type_item_unique").on(table.userId, table.favoriteType, table.favoriteItemId),
}));

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = typeof favorites.$inferInsert;

// ============================================================================
// 14. TABLE DES AVIS
// ============================================================================
export const reviews = mysqlTable("reviews", {
  id: int("id").autoincrement().primaryKey(),
  reviewerUserId: int("reviewerUserId").notNull().references(() => users.id, { onDelete: "cascade" }),
  trainerId: int("trainerId").notNull().references(() => trainers.id, { onDelete: "cascade" }),
  rating: int("rating").notNull(), // 1-5
  comment: text("comment"),
  isVerifiedPurchase: boolean("isVerifiedPurchase").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  trainerIdIdx: index("review_trainer_id_idx").on(table.trainerId),
  reviewerUserIdIdx: index("review_reviewer_id_idx").on(table.reviewerUserId),
}));

export type Review = typeof reviews.$inferSelect;
export type InsertReview = typeof reviews.$inferInsert;
