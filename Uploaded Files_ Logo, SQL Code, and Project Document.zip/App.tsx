import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import RoleSelection from "./pages/RoleSelection";
import OnboardingTrainer from "./pages/OnboardingTrainer";
import OnboardingOrganization from "./pages/OnboardingOrganization";
import Dashboard from "./pages/Dashboard";
import DashboardTrainer from "./pages/DashboardTrainer";
import DashboardOrganization from "./pages/DashboardOrganization";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/role-selection" component={RoleSelection} />
      <Route path="/onboarding/trainer" component={OnboardingTrainer} />
      <Route path="/onboarding/organization" component={OnboardingOrganization} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/dashboard/trainer" component={DashboardTrainer} />
      <Route path="/dashboard/organization" component={DashboardOrganization} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
