import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, Briefcase } from "lucide-react";

export default function RoleSelection() {
  const [, setLocation] = useLocation();
  const [selectedRole, setSelectedRole] = useState<"trainer" | "organization" | null>(null);

  const handleRoleSelect = (role: "trainer" | "organization") => {
    setSelectedRole(role);
    // Redirect to profile creation page based on role
    if (role === "trainer") {
      setLocation("/onboarding/trainer");
    } else {
      setLocation("/onboarding/organization");
    }
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-4xl">
        <div className="text-center mb-8">
          <img src="/logo.png" alt="Annuaire Formateur" className="h-16 w-16 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-primary mb-2">Bienvenue sur Annuaire Formateur</h1>
          <p className="text-muted-foreground">Choisissez votre profil pour commencer</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card
            className={`cursor-pointer transition-all hover:shadow-lg ${
              selectedRole === "trainer" ? "border-primary ring-2 ring-primary" : ""
            }`}
            onClick={() => handleRoleSelect("trainer")}
          >
            <CardHeader>
              <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <Users className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Je suis Formateur</CardTitle>
              <CardDescription className="text-base">
                Créez votre profil pour recevoir des opportunités de missions adaptées à vos compétences.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground mb-4">
                <li>✓ Créez votre profil expert</li>
                <li>✓ Recevez des alertes personnalisées</li>
                <li>✓ Accédez à des missions exclusives</li>
                <li>✓ Payez uniquement pour les opportunités qui vous intéressent (9€)</li>
              </ul>
              <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                Créer mon profil de formateur
              </Button>
            </CardContent>
          </Card>

          <Card
            className={`cursor-pointer transition-all hover:shadow-lg ${
              selectedRole === "organization" ? "border-primary ring-2 ring-primary" : ""
            }`}
            onClick={() => handleRoleSelect("organization")}
          >
            <CardHeader>
              <div className="flex h-16 w-16 items-center justify-center rounded-lg bg-secondary/10 mb-4">
                <Briefcase className="h-8 w-8 text-secondary" />
              </div>
              <CardTitle className="text-2xl">Je suis un Organisme de Formation</CardTitle>
              <CardDescription className="text-base">
                Accédez gratuitement à notre réseau de formateurs qualifiés et publiez vos missions.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground mb-4">
                <li>✓ Inscription et utilisation 100% gratuites</li>
                <li>✓ Recherchez des formateurs par compétence</li>
                <li>✓ Publiez vos missions sans limite</li>
                <li>✓ Contactez directement les formateurs</li>
              </ul>
              <Button className="w-full" variant="default">
                Créer mon compte organisme
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
