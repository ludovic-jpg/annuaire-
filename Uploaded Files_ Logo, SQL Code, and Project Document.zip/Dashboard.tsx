import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { user, loading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { data: profile, isLoading: profileLoading } = trpc.profile.getMyProfile.useQuery(undefined, {
    enabled: !!user,
  });

  useEffect(() => {
    if (authLoading || profileLoading) return;

    if (!user) {
      setLocation("/");
      return;
    }

    // If no profile exists, redirect to role selection
    if (!profile) {
      setLocation("/role-selection");
      return;
    }

    // Redirect based on role
    if (profile.type === "trainer") {
      setLocation("/dashboard/trainer");
    } else if (profile.type === "organization") {
      setLocation("/dashboard/organization");
    }
  }, [user, profile, authLoading, profileLoading, setLocation]);

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <div className="text-center">
        <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
        <p className="text-muted-foreground">Chargement...</p>
      </div>
    </div>
  );
}
